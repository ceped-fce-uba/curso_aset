
print("Este es un script de prueba para aprender automatizaciones")

b = 2 + 2

texto = paste0("El resultado de la suma es: ", b)

print(texto)


